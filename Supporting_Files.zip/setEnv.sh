@echo off

export CLIENT_HOME=%~dp0/../..
export API_CAINFO=%CLIENT_HOME%/clients/Essbase/EssbaseRTC/bin/cacerts.pem
export INSTANCE_NAME=donotuse


